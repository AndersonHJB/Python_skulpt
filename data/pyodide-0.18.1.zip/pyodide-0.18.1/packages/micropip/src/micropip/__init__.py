from .micropip import install

__all__ = ["install"]
