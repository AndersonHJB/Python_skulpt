(code-of-conduct)=

```{include} ../../CODE-OF-CONDUCT.md

```
