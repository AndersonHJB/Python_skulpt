(pyodide-build-cli)=

# pyodide-build CLI

```{eval-rst}
.. sphinx_argparse_cli::
   :module: pyodide_build.__main__
   :func: make_parser
   :prog: pyodide-build
   :title:
```
