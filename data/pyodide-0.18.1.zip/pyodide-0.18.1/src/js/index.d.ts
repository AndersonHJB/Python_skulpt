// This file is just needed to make "npx tsd" work (otherwise it will quit with an error).
