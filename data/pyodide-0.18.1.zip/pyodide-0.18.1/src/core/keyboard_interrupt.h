#ifndef KEYBOARD_INTERRUPT_H
#define KEYBOARD_INTERRUPT_H

int
keyboard_interrupt_init();

#endif /* KEYBOARD_INTERRUPT_H */
